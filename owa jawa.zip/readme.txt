This file download from the CadNav

100000+ Free 3D Models & CAD  Models download��https://www.cadnav.com��

High quality 3D Models Library, online 3D Models resource for CGI graphic designers and and 3D artists, daily updates will be posted on our site. 

Free 3D Models: https://www.cadnav.com/3d-models/
Vray materials library: https://www.cadnav.com/vray-materials/

You can download polygonal mesh 3D Models, Textures, Vray material, Software and plug-ins, etc. 

All of them in our website are FREE download.

INFO:��Please read and comply with the following terms and conditions before using, otherwise please don't use this model!

1. We doesn't accept any claims regarding quality of 3D model or any standards conformity.
2. We will not participate in any technology or copyright issues.
3. This file (models or textures) may be used in any commercial way only as a part of artwork or project. Single reselling or redistribution of this model is prohibited.  
4. This file (models or textures) may be freely modificated or elaborated.
5. If you use this file (models or textures) in your project or website, please indicate the source from cadnav.com


If you wanna rerelease the file in another website, please keep this info file included, thank you.

Remember to check often for new models at
https://www.cadnav.com

ENJOY! 